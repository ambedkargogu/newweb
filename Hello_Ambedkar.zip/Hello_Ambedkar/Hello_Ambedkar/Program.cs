﻿using System;
using static System.Console;

namespace Hello_Ambedkar
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello Ambedkar!");

            ReadKey();
        }
    };
}
